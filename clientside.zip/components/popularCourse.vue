<template>
  <div>
    <br>
    <v-container grid-list-lg>
      <v-layout>
        <v-flex xs11><h6>คอร์สที่ได้รับความนิยมใน "{{branchs}}"</h6></v-flex>
        <v-flex xs1 text-xs-right><nuxt-link :to="'/allcourse/'+mKey">ดูทั้งหมด</nuxt-link></v-flex>
      </v-layout>
      <v-layout row wrap>
        <template v-for="a in 4">
            <v-flex xs3>
              <nuxt-link to="/course/d" tag="span" style="cursor:pointer;">
                <v-card>
                  <v-card-media src="https://us.123rf.com/450wm/juliatim/juliatim1603/juliatim160300025/54282789-young-man-sitting-in-the-park-under-a-tree-and-working-with-laptop-flat-modern-illustration-of-socia.jpg?ver=6" height="150"></v-card-media>
                  <v-card-text>
                    <p>คอมพิวเตอร์เบื้องต้น (SP521)</p>
                    <span class="grey--text">Theerapat Vijitpoo</span><br>
                    <template v-for="a in 5">
                      <v-icon>star</v-icon>
                    </template>
                    <span>5.0 </span> <span class="grey--text">(33,888)</span>
                  </v-card-text>
                  <v-card-actions>
                    <v-spacer></v-spacer>
                    <h6 class="primary--text">350.-</h6>
                  </v-card-actions>
                </v-card>
              </nuxt-link>
            </v-flex>
        </template>
      </v-layout>
    </v-container>
  </div>
</template>
<script>
export default {
  props: ['branchs', 'mKey']
}
</script>
