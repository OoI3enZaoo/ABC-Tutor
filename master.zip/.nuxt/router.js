import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _7a3d1f92 = () => import('..\\pages\\index.vue' /* webpackChunkName: "pages\\index" */).then(m => m.default || m)
const _33c1da66 = () => import('..\\pages\\ทด.vue' /* webpackChunkName: "pages\\ทด" */).then(m => m.default || m)
const _39355068 = () => import('..\\pages\\tutor\\index.vue' /* webpackChunkName: "pages\\tutor\\index" */).then(m => m.default || m)
const _5ee2c2eb = () => import('..\\pages\\mycourse\\index.vue' /* webpackChunkName: "pages\\mycourse\\index" */).then(m => m.default || m)
const _43e4c2a9 = () => import('..\\pages\\login.vue' /* webpackChunkName: "pages\\login" */).then(m => m.default || m)
const _1e0db713 = () => import('..\\pages\\settings.vue' /* webpackChunkName: "pages\\settings" */).then(m => m.default || m)
const _2901fc9e = () => import('..\\pages\\signout.vue' /* webpackChunkName: "pages\\signout" */).then(m => m.default || m)
const _9e0c271c = () => import('..\\pages\\tutor\\create.vue' /* webpackChunkName: "pages\\tutor\\create" */).then(m => m.default || m)
const _63477a62 = () => import('..\\pages\\test\\store.vue' /* webpackChunkName: "pages\\test\\store" */).then(m => m.default || m)
const _689d2c7c = () => import('..\\pages\\test\\blank.vue' /* webpackChunkName: "pages\\test\\blank" */).then(m => m.default || m)
const _3a2f4189 = () => import('..\\pages\\test\\firebase.vue' /* webpackChunkName: "pages\\test\\firebase" */).then(m => m.default || m)
const _6ac783ef = () => import('..\\pages\\tutor\\manage\\_id.vue' /* webpackChunkName: "pages\\tutor\\manage\\_id" */).then(m => m.default || m)
const _5404f742 = () => import('..\\pages\\search\\_keyword.vue' /* webpackChunkName: "pages\\search\\_keyword" */).then(m => m.default || m)
const _260c48f7 = () => import('..\\pages\\mycourse\\_id.vue\\index.vue' /* webpackChunkName: "pages\\mycourse\\_id.vue\\index" */).then(m => m.default || m)
const _0128493f = () => import('..\\pages\\course\\_id.vue' /* webpackChunkName: "pages\\course\\_id" */).then(m => m.default || m)
const _68a10a2e = () => import('..\\pages\\allcourse\\_id.vue' /* webpackChunkName: "pages\\allcourse\\_id" */).then(m => m.default || m)
const _30eaf7da = () => import('..\\pages\\mycourse\\_id.vue' /* webpackChunkName: "pages\\mycourse\\_id" */).then(m => m.default || m)
const _8097e4e2 = () => import('..\\pages\\user\\_id.vue' /* webpackChunkName: "pages\\user\\_id" */).then(m => m.default || m)



const scrollBehavior = (to, from, savedPosition) => {
  // SavedPosition is only available for popstate navigations.
  if (savedPosition) {
    return savedPosition
  } else {
    let position = {}
    // If no children detected
    if (to.matched.length < 2) {
      // Scroll to the top of the page
      position = { x: 0, y: 0 }
    }
    else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
      // If one of the children has scrollToTop option set to true
      position = { x: 0, y: 0 }
    }
    // If link has anchor, scroll to anchor by returning the selector
    if (to.hash) {
      position = { selector: to.hash }
    }
    return position
  }
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/",
			component: _7a3d1f92,
			name: "index"
		},
		{
			path: "/ทด",
			component: _33c1da66,
			name: "ทด"
		},
		{
			path: "/tutor",
			component: _39355068,
			name: "tutor"
		},
		{
			path: "/mycourse",
			component: _5ee2c2eb,
			name: "mycourse"
		},
		{
			path: "/login",
			component: _43e4c2a9,
			name: "login"
		},
		{
			path: "/settings",
			component: _1e0db713,
			name: "settings"
		},
		{
			path: "/signout",
			component: _2901fc9e,
			name: "signout"
		},
		{
			path: "/tutor/create",
			component: _9e0c271c,
			name: "tutor-create"
		},
		{
			path: "/test/store",
			component: _63477a62,
			name: "test-store"
		},
		{
			path: "/test/blank",
			component: _689d2c7c,
			name: "test-blank"
		},
		{
			path: "/test/firebase",
			component: _3a2f4189,
			name: "test-firebase"
		},
		{
			path: "/tutor/manage/:id?",
			component: _6ac783ef,
			name: "tutor-manage-id"
		},
		{
			path: "/search/:keyword?",
			component: _5404f742,
			name: "search-keyword"
		},
		{
			path: "/mycourse/:id.vue",
			component: _260c48f7,
			name: "mycourse-id.vue"
		},
		{
			path: "/course/:id?",
			component: _0128493f,
			name: "course-id"
		},
		{
			path: "/allcourse/:id?",
			component: _68a10a2e,
			name: "allcourse-id"
		},
		{
			path: "/mycourse/:id",
			component: _30eaf7da,
			name: "mycourse-id"
		},
		{
			path: "/user/:id?",
			component: _8097e4e2,
			name: "user-id"
		}
    ],
    fallback: false
  })
}
