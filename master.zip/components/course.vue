<template>
  <div>

        <v-card>
          <v-card-text>
            <slot></slot>
          </v-card-text>
        </v-card>

  </div>
</template>
