<template>
  <div>
    <h5>realtime</h5>
    {{branchs}}
    <v-container>
    <v-layout wrap row>
      <template v-for="data in branchs">
          <v-flex xs4>
            <v-card>
              <v-card-text>{{data}}</v-card-text>
            </v-card>
            </v-flex>
      </template>
  </v-layout>
  </v-container>
  </div>
</template>
<script>
import { db } from '../../firebase'
let branchs = db.ref('courses')
export default {
  firebase: {
    branchs
  }
}
</script>
