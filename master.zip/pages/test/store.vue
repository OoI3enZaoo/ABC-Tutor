<template>
  <div>
    <h5>realtime</h5>
    {{course}}
    <v-container>
    <v-layout wrap row>
      <template v-for="data in course">
          <v-flex xs4>
            <v-card>
              <v-card-text>{{data}}</v-card-text>
            </v-card>
            </v-flex>
      </template>
  </v-layout>
  </v-container>
  </div>
</template>
<script>
export default {
  async asyncDaya ({ store }) {
    if (store.state.courseTest.length === 0) {
      await store.dispatch('PULL_COURSES_TEST')
    }
  },
  created () {
    console.log()
  },
  computed: {
    course () {
      return this.$store.state.courseTest
    }
  }
}
</script>
