import Vue from 'vue'
import VueAwesomeSwiper from 'vue-awesome-swiper/ssr'

Vue.use(VueAwesomeSwiper)
